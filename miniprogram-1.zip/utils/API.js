/*这里是模拟的接口返回数据*/

var orderinfo = [
//   {
//   imgGood: "../../icon/nopic.png",//商品图片地址
//   nameGood: "新鲜圣女果小番茄包邮批发时令 应季摘果小西红柿",//商品名称和描述
//   npriceGood: 23.9,//商品最新价格
//   opriceGood: 29.8,//商品以往价格
//   count: 10,//商品数量
//   id: 0,//商品id
//   selected: true,//商品是否为被选中状态，购物车首页默认全选
//   specifications: "500g"//商品规格
// },
//   {
//     imgGood: "../../icon/nopic.png",
//     nameGood: "水果胡萝卜3袋 新鲜枝纯小 红萝卜甜脆",
//     npriceGood: 9.9,
//     opriceGood: 19.8,
//     count: 5,
//     id: 1,
//     selected: true,
//     specifications: "3袋"
//   },
//   {
//     imgGood: "../../icon/nopic.png",
//     nameGood: "贝贝南瓜板栗味小南瓜糯面 粉日本南瓜新鲜10斤装",
//     npriceGood: 36.9,
//     opriceGood: 39.9,
//     count: 3,
//     id: 2,
//     selected: true,
//     specifications: "10斤"
//   }
]

  module.exports = {
    orderinfo: orderinfo
  }

